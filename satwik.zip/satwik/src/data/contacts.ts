import type { Contact } from '../types';
import { dedupeByName } from '../utils/dedupe';

const firstNames = [
  'Aarav','Diya','Ishaan','Maya','Rohan','Anya','Zara','Liam','Olivia','Noah',
  'Emma','Ava','Sophia','Mason','Isabella','Lucas','Mia','Ethan','Amelia','Aria'
];
const lastNames = [
  'Patel','Gupta','Sharma','Khan','Singh','Mehta','Shah','Brown','Smith','Johnson',
  'Williams','Jones','Garcia','Miller','Davis','Rodriguez','Martinez','Lopez','Gonzalez','Wilson'
];
const domains = ['example.com','mail.com','inbox.com','company.co','startup.io','dev.test'];

function pick<T>(arr: T[], i: number): T {
  return arr[i % arr.length];
}

export function generateContacts(count = 200): Contact[] {
  const result: Contact[] = [];
  for (let i = 0; i < count; i++) {
    const fn = pick(firstNames, i);
    const ln = pick(lastNames, count - i);
    const name = `${fn} ${ln}`;
    const email = `${fn.toLowerCase()}.${ln.toLowerCase()}${(i % 97) + 1}@${pick(domains, i + count)}`;
    const phone = `+1 ${String(200 + (i % 700)).padStart(3, '0')}-${String(100 + (i % 900)).padStart(3, '0')}-${String(1000 + i).slice(-4)}`;
    result.push({ id: `${i + 1}`, name, email, phone });
  }
  return result;
}

// Generates unique contacts by name, removing redundant entries of the same person.
// The maximum number of unique names equals firstNames.length * lastNames.length.
export function generateUniqueContacts(count = 200): Contact[] {
  const maxUnique = firstNames.length * lastNames.length;
  const needed = Math.min(count, maxUnique);

  // Produce a list cycling through unique name pairs deterministically
  const provisional: Contact[] = [];
  let idx = 0;
  while (provisional.length < needed) {
    const fn = firstNames[idx % firstNames.length];
    const ln = lastNames[Math.floor(idx / firstNames.length) % lastNames.length];
    const name = `${fn} ${ln}`;
    const email = `${fn.toLowerCase()}.${ln.toLowerCase()}@${domains[(idx + 3) % domains.length]}`;
    const phone = `+1 ${String(300 + (idx % 600)).padStart(3, '0')}-${String(120 + (idx % 800)).padStart(3, '0')}-${String(1000 + idx).slice(-4)}`;
    provisional.push({ id: `${idx + 1}`, name, email, phone });
    idx++;
  }

  return dedupeByName(provisional).slice(0, needed);
}
