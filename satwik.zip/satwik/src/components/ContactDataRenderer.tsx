import React, { useMemo, useState } from 'react';
import type { Contact } from '../types';
import ContactCard from './ContactCard';
import { dedupeByName } from '../utils/dedupe';

interface Props {
  contacts: Contact[];
}

export default function ContactDataRenderer({ contacts }: Props) {
  const [query, setQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | string>('all');

  const domainFromEmail = (email: string) => email.split('@')[1]?.toLowerCase() ?? '';
  const typeOptions = useMemo(() => {
    const set = new Set<string>();
    for (const c of contacts) set.add(domainFromEmail(c.email));
    return Array.from(set).sort();
  }, [contacts]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = typeFilter === 'all'
      ? contacts
      : contacts.filter((c) => domainFromEmail(c.email) === typeFilter);
    if (!q) return dedupeByName(base);
    return dedupeByName(
      base.filter((c) =>
        c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q)
      )
    );
  }, [contacts, query, typeFilter]);

  return (
    <section className="contact-section">
      <div className="filter-bar">
        <label htmlFor="filter-input" className="visually-hidden">
          Filter contacts
        </label>
        <input
          id="filter-input"
          type="search"
          placeholder="Search contacts by name or email"
          className="filter-input"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoComplete="off"
        />
        <label htmlFor="type-filter" className="visually-hidden">Filter by type</label>
        <select
          id="type-filter"
          className="filter-select"
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
        >
          <option value="all">All types</option>
          {typeOptions.map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
        <div className="result-count" aria-live="polite">
          {filtered.length} result{filtered.length !== 1 ? 's' : ''}
        </div>
      </div>

      <div className="contact-list" role="list" aria-label="Contacts">
        {filtered.map((c) => (
          <ContactCard key={c.id} contact={c} />
        ))}
        {filtered.length === 0 && (
          <div className="empty-state" role="status">
            No contacts found.
          </div>
        )}
      </div>
    </section>
  );
}