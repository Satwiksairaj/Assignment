import React from 'react';
import type { Contact } from '../types';

interface Props {
  contact: Contact;
}

export default function ContactCard({ contact }: Props) {
  return (
    <div className="contact-card" role="listitem">
      <div className="contact-avatar" aria-hidden="true">
        {contact.name
          .split(' ')
          .map((n) => n[0])
          .slice(0, 2)
          .join('')}
      </div>
      <div className="contact-details">
        <div className="contact-name">{contact.name}</div>
        <div className="contact-email">{contact.email}</div>
        <div className="contact-phone">{contact.phone}</div>
      </div>
    </div>
  );
}

