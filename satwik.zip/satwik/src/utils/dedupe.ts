import type { Contact } from '../types';

export function dedupeBy<T>(items: T[], getKey: (item: T) => string): T[] {
  const seen = new Set<string>();
  const result: T[] = [];
  for (const item of items) {
    const k = getKey(item).trim().toLowerCase();
    if (!seen.has(k)) {
      seen.add(k);
      result.push(item);
    }
  }
  return result;
}

// Convenience helpers for contacts
export const dedupeByEmail = (contacts: Contact[]) =>
  dedupeBy(contacts, (c) => c.email);

export const dedupeByName = (contacts: Contact[]) =>
  dedupeBy(contacts, (c) => c.name);

