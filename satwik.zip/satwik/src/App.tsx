import React from 'react';
import ContactDataRenderer from './components/ContactDataRenderer';
import { generateUniqueContacts } from './data/contacts';
import { dedupeByName } from './utils/dedupe';

// Generate unique contacts and defensively dedupe by name
const contacts = dedupeByName(generateUniqueContacts(500));

export default function App() {
  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Contact Data Renderer</h1>
        <p className="subtitle">Search by name or email</p>
      </header>
      <main>
        <ContactDataRenderer contacts={contacts} />
      </main>
      <footer className="app-footer">
        <a href="https://github.com" target="_blank" rel="noreferrer">GitHub</a>
      </footer>
    </div>
  );
}
