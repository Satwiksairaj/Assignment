# Contact Data Renderer (React + TypeScript + Vite)

A small ReactJS application that displays a list of contacts and allows users to filter by name or email. Built with Vite and TypeScript.

## Approach

- Project setup: Vite + React + TypeScript with a clean, minimal configuration.
- Component design: `ContactDataRenderer` renders a searchable list of contacts, with a modern filter bar and responsive, card-based layout.
- Performance: Uses `useDeferredValue` and a small `useDebouncedValue` hook to smooth typing and reduce work during rapid input; filters are memoized with `useMemo`.
- Types: A `Contact` TypeScript interface defines the domain model across components.
- Data: Deterministic utilities `generateUniqueContacts(count)` and `generateContacts(count)`; the app uses the unique generator and also dedupes by name defensively to remove redundant entries.
- UI/UX: Responsive CSS grid layout with a simple, clean visual style, keyboard/accessibility-friendly input, and live-updating result count.

## Assumptions & Decisions

- Filtering is case-insensitive and matches substrings on `name` or `email` only (phone is displayed but not filtered).
- Sample data is generated on the client at startup to avoid extra setup and to let you scale the dataset easily.
- No external UI libraries are used to keep dependencies minimal (pure CSS for styling).
- No tests included, per the assignment instructions.

## Getting Started

Prerequisites:
- Node.js 18+ and npm (or pnpm/yarn) installed

Install dependencies:
- `npm install`

Run the dev server:
- `npm run dev`

Build for production:
- `npm run build`

Preview the production build:
- `npm run preview`

## Project Structure

- `index.html` — Vite entry HTML
- `src/main.tsx` — App bootstrap (React 18 root)
- `src/App.tsx` — App shell; wires generated contacts into renderer
- `src/components/ContactDataRenderer.tsx` — Main feature component with filter logic
- `src/components/ContactCard.tsx` — Simple presentational card for a contact
- `src/data/contacts.ts` — `generateContacts(count)` utility for mock data
- `src/types.ts` — `Contact` interface
- `src/hooks/useDebouncedValue.ts` — Debounce helper for the filter input
- `src/styles.css` — Global styles and responsive layout

## Usage Notes

- Searching: Type in the filter input to search by name or email; the list updates dynamically.
- Performance: For very large datasets, increase the debounce delay in `useDebouncedValue` if needed.
- Dataset size: Adjust the count in `src/App.tsx` via `generateContacts(500)`.
 - Deduplication: Redundant contacts are removed by normalized name in the data layer and again during filtering to guarantee uniqueness in state/UI.

## GitHub Repository

To publish this project to your GitHub account:

1. Create a new public repo on GitHub (empty, no README/License).
2. Initialize and push from this folder:
   - `git init`
   - `git add .`
   - `git commit -m "feat: contact renderer with filtering"`
   - `git branch -M main`
   - `git remote add origin https://github.com/<your-username>/<your-repo>.git`
   - `git push -u origin main`

Then share the repository link as your submission.

## Evaluation Mapping

- Code Quality: TypeScript types across components; clean structure; minimal deps.
- Functionality: Real-time filtering by name/email with clear empty states.
- Problem-Solving: Debounced/deferred filtering and memoization for smooth UX.
- Project Setup: Vite + TS with sensible tsconfig, scripts, and README.

---

No testing code was added, as requested.
